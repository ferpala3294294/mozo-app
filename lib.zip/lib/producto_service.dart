import 'dart:convert';
import 'package:http/http.dart' as http;

class ProductoService {
  // =====================================================
  // URL DE LARAVEL
  // =====================================================

  static const String baseUrl = 'http://127.0.0.1:8000';

  // =====================================================
  // OBTENER PRODUCTOS
  // =====================================================

  static Future<List<Map<String, dynamic>>> obtenerProductos() async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/productos'),
    );

    if (response.statusCode == 200) {
      final List<dynamic> datos = jsonDecode(response.body);

      return datos
          .map(
            (producto) =>
                Map<String, dynamic>.from(producto),
          )
          .toList();
    }

    throw Exception(
      'Error al obtener los productos. '
      'Código: ${response.statusCode}',
    );
  }
}