import 'login_screen.dart';
import 'package:flutter/material.dart';
import 'categoria_pizzas_screen.dart';
import 'categoria_empanadas_screen.dart';
import 'categoria_bebidas_screen.dart';
import 'mesas_pedido_screen.dart';
import 'pedido_manager.dart';

class CategoriaSandwichesScreen extends StatefulWidget {
  final int mesa;

  const CategoriaSandwichesScreen({
    super.key,
    required this.mesa,
  });

  @override
  State<CategoriaSandwichesScreen> createState() =>
      _CategoriaSandwichesScreenState();
}

class _CategoriaSandwichesScreenState
    extends State<CategoriaSandwichesScreen> {
  String productoSeleccionado = 'Suizo';

  static const Color azulOscuro = Color(0xFF174A75);
  static const Color azulBoton = Color(0xFF4E82A6);

  final PedidoManager pedidoManager = PedidoManager.instancia;

  @override
  void initState() {
    super.initState();

    pedidoManager.addListener(actualizarCarrito);
  }

  @override
  void dispose() {
    pedidoManager.removeListener(actualizarCarrito);
    super.dispose();
  }

  void actualizarCarrito() {
    if (mounted) {
      setState(() {});
    }
  }

  int convertirPrecio(String precio) {
    final limpio = precio
        .replaceAll('\$', '')
        .replaceAll('.', '')
        .replaceAll(',', '.')
        .trim();

    return double.parse(limpio).toInt();
  }

  void abrirPanelAgregarPedido({
    required String nombre,
    required String precio,
  }) {
    int cantidad = 1;

    // NUEVO: opción de papas
    String opcionPapas = 'Sin papas';

    final observacionController = TextEditingController();

    final precioBase = convertirPrecio(precio);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            // NUEVO: precio según la opción elegida
            final precioFinal = opcionPapas == 'Con papas'
                ? precioBase + 1000
                : precioBase;

            final precioMostrar =
                '\$${precioFinal.toString().replaceAllMapped(
                      RegExp(r'\B(?=(\d{3})+(?!\d))'),
                      (match) => '.',
                    )},00';

            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
              ),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(22),
                  ),
                ),
                child: SafeArea(
                  top: false,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'AGREGAR AL PEDIDO',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: azulOscuro,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: const Icon(
                                Icons.close,
                                color: azulOscuro,
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 15),

                        Container(
                          height: 100,
                          decoration: BoxDecoration(
                            color: const Color(0xFFF1F1F1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 100,
                                height: double.infinity,
                                decoration: BoxDecoration(
                                  color: const Color(0xFFD8D8D8),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: const Icon(
                                  Icons.image_outlined,
                                  color: Colors.white,
                                  size: 40,
                                ),
                              ),

                              const SizedBox(width: 15),

                              Expanded(
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.center,
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      nombre,
                                      style: const TextStyle(
                                        color: azulOscuro,
                                        fontSize: 17,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),

                                    const SizedBox(height: 6),

                                    Text(
                                      precioMostrar,
                                      style: const TextStyle(
                                        color: Colors.green,
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 15),

                        // NUEVO: OPCIÓN DE PAPAS
                        const Text(
                          'OPCIÓN',
                          style: TextStyle(
                            color: azulOscuro,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        const SizedBox(height: 6),

                        Row(
                          children: [
                            Expanded(
                              child: GestureDetector(
                                onTap: () {
                                  setModalState(() {
                                    opcionPapas = 'Sin papas';
                                  });
                                },
                                child: Container(
                                  height: 42,
                                  decoration: BoxDecoration(
                                    color: opcionPapas == 'Sin papas'
                                        ? azulOscuro
                                        : Colors.white,
                                    border: Border.all(
                                      color: azulBoton,
                                    ),
                                    borderRadius:
                                        BorderRadius.circular(8),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Sin papas',
                                      style: TextStyle(
                                        color: opcionPapas == 'Sin papas'
                                            ? Colors.white
                                            : azulOscuro,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(width: 8),

                            Expanded(
                              child: GestureDetector(
                                onTap: () {
                                  setModalState(() {
                                    opcionPapas = 'Con papas';
                                  });
                                },
                                child: Container(
                                  height: 42,
                                  decoration: BoxDecoration(
                                    color: opcionPapas == 'Con papas'
                                        ? azulOscuro
                                        : Colors.white,
                                    border: Border.all(
                                      color: azulBoton,
                                    ),
                                    borderRadius:
                                        BorderRadius.circular(8),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Con papas +\$1.000',
                                      style: TextStyle(
                                        color: opcionPapas == 'Con papas'
                                            ? Colors.white
                                            : azulOscuro,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 18),

                        const Text(
                          'CANTIDAD',
                          style: TextStyle(
                            color: azulOscuro,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        const SizedBox(height: 6),

                        Container(
                          height: 50,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: azulBoton,
                            ),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: IconButton(
                                  onPressed: cantidad > 1
                                      ? () {
                                          setModalState(() {
                                            cantidad--;
                                          });
                                        }
                                      : null,
                                  icon: const Icon(
                                    Icons.remove,
                                    color: azulOscuro,
                                  ),
                                ),
                              ),

                              Expanded(
                                child: Center(
                                  child: Text(
                                    '$cantidad',
                                    style: const TextStyle(
                                      color: azulOscuro,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),

                              Expanded(
                                child: IconButton(
                                  onPressed: () {
                                    setModalState(() {
                                      cantidad++;
                                    });
                                  },
                                  icon: const Icon(
                                    Icons.add,
                                    color: azulOscuro,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 18),

                        const Text(
                          'DETALLE / OBSERVACIÓN',
                          style: TextStyle(
                            color: azulOscuro,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        const SizedBox(height: 6),

                        TextField(
                          controller: observacionController,
                          maxLines: 2,
                          decoration: InputDecoration(
                            hintText:
                                'Ej: Sin cebolla, sin tomate...',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(
                                color: azulOscuro,
                                width: 2,
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 20),

                        SizedBox(
                          width: double.infinity,
                          height: 48,
                          child: ElevatedButton.icon(
                            onPressed: () {
                              String observacion =
                                  observacionController.text.trim();

                              // NUEVO: guardamos la opción de papas
                              if (opcionPapas == 'Con papas') {
                                if (observacion.isNotEmpty) {
                                  observacion =
                                      'Con papas - $observacion';
                                } else {
                                  observacion = 'Con papas';
                                }
                              } else {
                                if (observacion.isNotEmpty) {
                                  observacion =
                                      'Sin papas - $observacion';
                                } else {
                                  observacion = 'Sin papas';
                                }
                              }

                              pedidoManager.agregarProducto(
                                mesa: widget.mesa,
                                producto: nombre,
                                categoria: 'Sandwiches',
                                cantidad: cantidad,
                                precioUnitario: precioFinal,
                                observacion: observacion,
                              );

                              Navigator.pop(context);

                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    '$cantidad x $nombre agregado al pedido',
                                  ),
                                  duration:
                                      const Duration(seconds: 2),
                                ),
                              );
                            },
                            icon: const Icon(Icons.add),
                            label: const Text(
                              'AGREGAR AL PEDIDO',
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: azulOscuro,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    ).whenComplete(() {
      observacionController.dispose();
    });
  }

  void abrirPanelUsuario(BuildContext context) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Usuario',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 300),
      pageBuilder: (context, animation, secondaryAnimation) {
        return Align(
          alignment: Alignment.centerRight,
          child: Material(
            color: Colors.transparent,
            child: SizedBox(
              width: MediaQuery.of(context).size.width < 600
                  ? MediaQuery.of(context).size.width * 0.88
                  : 420,
              height: double.infinity,
              child: Container(
                color: Colors.white,
                child: SafeArea(
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerRight,
                        child: IconButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          icon: const Icon(
                            Icons.close,
                            color: azulOscuro,
                            size: 32,
                          ),
                        ),
                      ),

                      const SizedBox(height: 25),

                      Container(
                        width: 130,
                        height: 130,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFFE9E9E9),
                          border: Border.all(
                            color: azulOscuro,
                            width: 2,
                          ),
                        ),
                        child: const Icon(
                          Icons.person,
                          size: 85,
                          color: azulOscuro,
                        ),
                      ),

                      const SizedBox(height: 25),

                      const Text(
                        'Fernando Palavecino',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: azulOscuro,
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 8),

                      const Text(
                        'Mozo',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 20,
                        ),
                      ),

                      const SizedBox(height: 30),

                      const Divider(
                        thickness: 1,
                        indent: 30,
                        endIndent: 30,
                      ),

                      ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 35,
                          vertical: 8,
                        ),
                        leading: const Icon(
                          Icons.logout,
                          color: Colors.red,
                          size: 30,
                        ),
                        title: const Text(
                          'Cerrar sesión',
                          style: TextStyle(
                            color: Colors.red,
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        onTap: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  const LoginScreen(),
                            ),
                            (route) => false,
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (
        context,
        animation,
        secondaryAnimation,
        child,
      ) {
        final desplazamiento = Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(
          CurvedAnimation(
            parent: animation,
            curve: Curves.easeOut,
          ),
        );

        return SlideTransition(
          position: desplazamiento,
          child: child,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: SafeArea(
        child: Column(
          children: [
            // BARRA SUPERIOR
            Container(
              height: 67,
              color: Colors.white,
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.arrow_back_ios_new,
                      color: azulOscuro,
                      size: 27,
                    ),
                  ),

                  const Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Categoría',
                          style: TextStyle(
                            color: azulOscuro,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Sandwiches',
                          style: TextStyle(
                            color: azulOscuro,
                            fontSize: 19,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // CARRITO
                  Stack(
                    clipBehavior: Clip.none,
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  const MesasPedidoScreen(),
                            ),
                          );
                        },
                        icon: const Icon(
                          Icons.shopping_cart_outlined,
                          color: azulOscuro,
                          size: 28,
                        ),
                      ),

                      if (pedidoManager.cantidadProductos > 0)
                        Positioned(
                          right: 2,
                          top: 0,
                          child: Container(
                            constraints: const BoxConstraints(
                              minWidth: 18,
                              minHeight: 18,
                            ),
                            padding:
                                const EdgeInsets.symmetric(
                              horizontal: 4,
                            ),
                            decoration: BoxDecoration(
                              color: azulOscuro,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Colors.white,
                                width: 1.5,
                              ),
                            ),
                            child: Center(
                              child: Text(
                                '${pedidoManager.cantidadProductos}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),

                  // USUARIO
                  GestureDetector(
                    onTap: () {
                      abrirPanelUsuario(context);
                    },
                    child: Container(
                      margin: const EdgeInsets.only(
                        left: 5,
                        right: 12,
                      ),
                      width: 39,
                      height: 39,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: azulOscuro,
                          width: 2,
                        ),
                      ),
                      child: const Icon(
                        Icons.person,
                        color: azulOscuro,
                        size: 27,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // CONTENIDO
            Expanded(
              child: SingleChildScrollView(
                padding:
                    const EdgeInsets.fromLTRB(7, 8, 7, 20),
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        categoriaBoton(
                          icono: Icons.lunch_dining,
                          onTap: () {},
                        ),
                        const SizedBox(width: 14),
                        categoriaBoton(
                          icono: Icons.local_pizza,
                          onTap: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    CategoriaPizzasScreen(
                                  mesa: widget.mesa,
                                ),
                              ),
                            );
                          },
                        ),
                        const SizedBox(width: 14),
                        categoriaBoton(
                          icono: Icons.bakery_dining,
                          onTap: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    CategoriaEmpanadasScreen(
                                  mesa: widget.mesa,
                                ),
                              ),
                            );
                          },
                        ),
                        const SizedBox(width: 14),
                        categoriaBoton(
                          icono: Icons.local_drink,
                          onTap: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    CategoriaBebidasScreen(
                                  mesa: widget.mesa,
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),

                    const SizedBox(height: 10),

                    tituloSeccion('Hamburguesas'),

                    filaProductos([
                      producto(
                        nombre: 'Hamburguesa Simple',
                        precio: '\$10.000,00',
                      ),
                      producto(
                        nombre: 'Hamburguesa Mexicana',
                        precio: '\$8.500,00',
                      ),
                    ]),

                    const SizedBox(height: 8),

                    tituloSeccion('Lomitos'),

                    filaProductos([
                      producto(
                        nombre: 'Lomito Simple',
                        precio: '\$15.000,00',
                      ),
                      producto(
                        nombre: 'Lomito Completo',
                        precio: '\$17.000,00',
                      ),
                    ]),

                    const SizedBox(height: 8),

                    tituloSeccion('Charly / Suizo'),

                    filaProductos([
                      producto(
                        nombre: 'Charly',
                        precio: '\$15.000,00',
                      ),
                      producto(
                        nombre: 'Suizo',
                        precio: '\$16.000,00',
                      ),
                    ]),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget categoriaBoton({
    required IconData icono,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 25,
          decoration: BoxDecoration(
            color: azulBoton,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Center(
            child: Icon(
              icono,
              color: Colors.white,
              size: 18,
            ),
          ),
        ),
      ),
    );
  }

  Widget tituloSeccion(String texto) {
    return Padding(
      padding: const EdgeInsets.only(
        left: 1,
        bottom: 5,
      ),
      child: Text(
        texto,
        style: const TextStyle(
          color: azulOscuro,
          fontSize: 17,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget filaProductos(List<Widget> productos) {
    return Row(
      children: [
        Expanded(child: productos[0]),
        const SizedBox(width: 20),
        Expanded(child: productos[1]),
      ],
    );
  }

  Widget producto({
    required String nombre,
    required String precio,
  }) {
    final seleccionado =
        productoSeleccionado == nombre;

    return GestureDetector(
      onTap: () {
        setState(() {
          productoSeleccionado = nombre;
        });

        abrirPanelAgregarPedido(
          nombre: nombre,
          precio: precio,
        );
      },
      child: Container(
        height: 87,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(9),
          border: Border.all(
            color: seleccionado
                ? Colors.blue
                : Colors.transparent,
            width: seleccionado ? 2 : 1,
          ),
          boxShadow: const [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 3,
              offset: Offset(0, 1),
            ),
          ],
        ),
        child: Column(
          children: [
            Expanded(
              child: Container(
                margin: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  color: const Color(0xFFD8D8D8),
                  borderRadius:
                      BorderRadius.circular(7),
                ),
                child: const Center(
                  child: Icon(
                    Icons.image_outlined,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
              ),
            ),

            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.only(
                  left: 5,
                ),
                child: Text(
                  nombre,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 7,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),

            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.only(
                  left: 5,
                  bottom: 3,
                ),
                child: Text(
                  precio,
                  style: const TextStyle(
                    color: Colors.green,
                    fontSize: 6,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}