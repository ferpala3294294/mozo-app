import 'package:flutter/material.dart';
import 'categorias_screen.dart';
import 'detalle.dart';
import 'login_screen.dart';

class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  // ============================================================
  // COLORES
  // ============================================================

  static const Color azulFondo = Color(0xFF004B7A);
  static const Color azulTarjeta = Color(0xFF004B7A);
  static const Color azulTarjetaOcupada = Color(0xFF78A8C5);
  static const Color azulOscuro = Color(0xFF174A75);
  static const Color azul = Color(0xFF004B7A);
  static const Color fondo = Color(0xFFE9F2F8);

  // ============================================================
  // ESTADO DE LAS MESAS
  // ============================================================

  final List<bool> mesasOcupadas = const [
    false,
    false,
    true,
    false,
    true,
    false,
    false,
    true,
    false,
    false,
  ];

  // ============================================================
  // PANEL DE USUARIO
  // ============================================================

  void abrirPanelUsuario(BuildContext context) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Perfil',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 300),
      pageBuilder: (context, animation, secondaryAnimation) {
        return Align(
          alignment: Alignment.centerRight,
          child: Material(
            color: Colors.transparent,
            child: LayoutBuilder(
              builder: (context, constraints) {
                final anchoPantalla = constraints.maxWidth;

                final anchoPanel =
                    anchoPantalla < 600
                        ? anchoPantalla * 0.88
                        : 420.0;

                return SizedBox(
                  width: anchoPanel,
                  height: double.infinity,
                  child: Container(
                    color: Colors.white,
                    child: SafeArea(
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Align(
                              alignment: Alignment.centerRight,
                              child: IconButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                icon: const Icon(
                                  Icons.close,
                                  color: azulOscuro,
                                  size: 32,
                                ),
                              ),
                            ),

                            const SizedBox(height: 25),

                            Container(
                              width: 130,
                              height: 130,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xFFE9E9E9),
                                border: Border.all(
                                  color: azulOscuro,
                                  width: 2,
                                ),
                              ),
                              child: const Icon(
                                Icons.person,
                                size: 85,
                                color: azulOscuro,
                              ),
                            ),

                            const SizedBox(height: 25),

                            const Text(
                              'Fernando Palavecino',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: azulOscuro,
                                fontSize: 26,
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            const SizedBox(height: 8),

                            const Text(
                              'Mozo',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 20,
                              ),
                            ),

                            const SizedBox(height: 30),

                            const Divider(
                              thickness: 1,
                              indent: 30,
                              endIndent: 30,
                            ),

                            ListTile(
                              contentPadding:
                                  const EdgeInsets.symmetric(
                                horizontal: 35,
                                vertical: 8,
                              ),
                              leading: const Icon(
                                Icons.logout,
                                color: Colors.red,
                                size: 30,
                              ),
                              title: const Text(
                                'Cerrar sesión',
                                style: TextStyle(
                                  color: Colors.red,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              onTap: () {
                                Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const LoginScreen(),
                                  ),
                                  (route) => false,
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
      transitionBuilder: (
        context,
        animation,
        secondaryAnimation,
        child,
      ) {
        final desplazamiento = Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(
          CurvedAnimation(
            parent: animation,
            curve: Curves.easeOut,
          ),
        );

        return SlideTransition(
          position: desplazamiento,
          child: child,
        );
      },
    );
  }

  // ============================================================
  // PANTALLA
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: azulFondo,
      body: SafeArea(
        child: Column(
          children: [
            // ======================================================
            // BARRA SUPERIOR
            // ======================================================

            Container(
              height: 58,
              color: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      abrirPanelUsuario(context);
                    },
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: azulOscuro,
                          width: 2,
                        ),
                      ),
                      child: const Icon(
                        Icons.person,
                        color: azulOscuro,
                        size: 26,
                      ),
                    ),
                  ),

                  const Spacer(),

                  IconButton(
                    onPressed: () {},
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(
                      minWidth: 40,
                      minHeight: 40,
                    ),
                    icon: const Icon(
                      Icons.notifications_none,
                      color: azulOscuro,
                      size: 28,
                    ),
                  ),
                ],
              ),
            ),

            // ======================================================
            // CONTENIDO
            // ======================================================

            Expanded(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final ancho = constraints.maxWidth;
                  final esCelular = ancho < 600;

                  final paddingHorizontal =
                      esCelular
                          ? (ancho * 0.04).clamp(10.0, 18.0)
                          : 32.0;

                  return SingleChildScrollView(
                    padding: EdgeInsets.symmetric(
                      horizontal: paddingHorizontal,
                      vertical: esCelular ? 18 : 28,
                    ),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(
                          maxWidth: 900,
                        ),
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: fondo,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              // ==================================================
                              // TITULO MESAS
                              // ==================================================

                              const Text(
                                'MESAS',
                                style: TextStyle(
                                  color: azulOscuro,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),

                              const SizedBox(height: 14),

                              // ==================================================
                              // MESAS
                              // ==================================================

                              GridView.builder(
                                shrinkWrap: true,
                                physics:
                                    const NeverScrollableScrollPhysics(),
                                itemCount: mesasOcupadas.length,
                                gridDelegate:
                                    SliverGridDelegateWithFixedCrossAxisCount(
                                  // CELULAR = 2 COLUMNAS
                                  // PANTALLA GRANDE = 5 COLUMNAS
                                  crossAxisCount:
                                      esCelular ? 2 : 5,

                                  crossAxisSpacing:
                                      esCelular ? 6 : 8,

                                  mainAxisSpacing:
                                      esCelular ? 6 : 8,

                                  childAspectRatio:
                                      esCelular ? 1.05 : 1.05,
                                ),
                                itemBuilder: (context, index) {
                                  final numero = index + 1;
                                  final ocupada =
                                      mesasOcupadas[index];

                                  return GestureDetector(
                                    onTap: ocupada
                                        ? null
                                        : () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    DetalleScreen(
                                                  mesa: numero,
                                                ),
                                              ),
                                            );
                                          },
                                    child: Container(
                                      decoration: BoxDecoration(
                                        // LIBRE = AZUL OSCURO
                                        // OCUPADA = AZUL CLARO
                                        color: ocupada
                                            ? azulTarjetaOcupada
                                            : azulTarjeta,

                                        borderRadius:
                                            BorderRadius.circular(10),
                                      ),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          // ==================================================
                                          // ICONO MESA
                                          // ==================================================

                                          Icon(
                                            Icons.table_restaurant,
                                            color: Colors.white,
                                            size: esCelular
                                                ? 30
                                                : 32,
                                          ),

                                          const SizedBox(height: 7),

                                          // ==================================================
                                          // NUMERO DE MESA
                                          // ==================================================

                                          Text(
                                            'MESA $numero',
                                            style:
                                                const TextStyle(
                                              color: Colors.white,
                                              fontSize: 13,
                                              fontWeight:
                                                  FontWeight.bold,
                                            ),
                                          ),

                                          const SizedBox(height: 5),

                                          // ==================================================
                                          // ESTADO
                                          // ==================================================

                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment
                                                    .center,
                                            children: [
                                              Container(
                                                width: 9,
                                                height: 9,
                                                decoration:
                                                    BoxDecoration(
                                                  color: ocupada
                                                      ? Colors.red
                                                      : Colors.green,
                                                  shape:
                                                      BoxShape.circle,
                                                ),
                                              ),

                                              const SizedBox(width: 5),

                                              Text(
                                                ocupada
                                                    ? 'OCUPADA'
                                                    : 'LIBRE',
                                                style:
                                                    const TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 8,
                                                  fontWeight:
                                                      FontWeight.bold,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}