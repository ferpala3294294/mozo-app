import 'package:flutter/material.dart';
import 'confirmar_pedido_screen.dart';
import 'menu_screen.dart';
import 'login_screen.dart';
import 'pedido_manager.dart';

class MesasPedidoScreen extends StatefulWidget {
  const MesasPedidoScreen({super.key});

  @override
  State<MesasPedidoScreen> createState() => _MesasPedidoScreenState();
}

class _MesasPedidoScreenState extends State<MesasPedidoScreen> {
  static const Color azulOscuro = Color(0xFF174A75);
  static const Color fondo = Color(0xFFF5F5F5);

  final PedidoManager pedidoManager = PedidoManager.instancia;

  @override
  void initState() {
    super.initState();
    pedidoManager.addListener(actualizarPedido);
  }

  @override
  void dispose() {
    pedidoManager.removeListener(actualizarPedido);
    super.dispose();
  }

  void actualizarPedido() {
    if (mounted) {
      setState(() {});
    }
  }

  int calcularTotal() {
    int total = 0;

    for (final item in pedidoManager.pedido) {
      total += item['precio'] as int;
    }

    return total;
  }

  int obtenerMesa() {
    if (pedidoManager.pedido.isEmpty) {
      return 0;
    }

    return pedidoManager.pedido.first['mesa'] as int;
  }

  void eliminarProducto(int index) {
    pedidoManager.eliminarProducto(index);
  }

  void enviarPedido() {
    final pedido = pedidoManager.pedido;

    if (pedido.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No hay productos en el pedido.'),
        ),
      );
      return;
    }

    final mesa = obtenerMesa();

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ConfirmarPedidoScreen(
          mesa: 'MESA $mesa',
          pedido: pedido,
        ),
      ),
    );
  }

  void abrirPanelUsuario(BuildContext context) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Usuario',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 300),
      pageBuilder: (context, animation, secondaryAnimation) {
        return Align(
          alignment: Alignment.centerRight,
          child: Material(
            color: Colors.transparent,
            child: SizedBox(
              width: MediaQuery.of(context).size.width < 600
                  ? MediaQuery.of(context).size.width * 0.88
                  : 420,
              height: double.infinity,
              child: Container(
                color: Colors.white,
                child: SafeArea(
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerRight,
                        child: IconButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          icon: const Icon(
                            Icons.close,
                            color: azulOscuro,
                            size: 32,
                          ),
                        ),
                      ),

                      const SizedBox(height: 25),

                      Container(
                        width: 130,
                        height: 130,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFFE9E9E9),
                          border: Border.all(
                            color: azulOscuro,
                            width: 2,
                          ),
                        ),
                        child: const Icon(
                          Icons.person,
                          size: 85,
                          color: azulOscuro,
                        ),
                      ),

                      const SizedBox(height: 25),

                      const Text(
                        'Fernando Palavecino',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: azulOscuro,
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 8),

                      const Text(
                        'Mozo',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 20,
                        ),
                      ),

                      const SizedBox(height: 30),

                      const Divider(
                        thickness: 1,
                        indent: 30,
                        endIndent: 30,
                      ),

                      ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 35,
                          vertical: 8,
                        ),
                        leading: const Icon(
                          Icons.logout,
                          color: Colors.red,
                          size: 30,
                        ),
                        title: const Text(
                          'Cerrar sesión',
                          style: TextStyle(
                            color: Colors.red,
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        onTap: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const LoginScreen(),
                            ),
                            (route) => false,
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (
        context,
        animation,
        secondaryAnimation,
        child,
      ) {
        final desplazamiento = Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(
          CurvedAnimation(
            parent: animation,
            curve: Curves.easeOut,
          ),
        );

        return SlideTransition(
          position: desplazamiento,
          child: child,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final pedido = pedidoManager.pedido;
    final mesa = obtenerMesa();

    return Scaffold(
      backgroundColor: fondo,
      body: SafeArea(
        child: Column(
          children: [
            // BARRA SUPERIOR
            Container(
              height: 67,
              color: Colors.white,
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.arrow_back_ios_new,
                      color: azulOscuro,
                      size: 27,
                    ),
                  ),

                  const Expanded(
                    child: Text(
                      'PEDIDO',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: azulOscuro,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),

                  GestureDetector(
                    onTap: () {
                      abrirPanelUsuario(context);
                    },
                    child: Container(
                      margin: const EdgeInsets.only(right: 12),
                      width: 39,
                      height: 39,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: azulOscuro,
                          width: 2,
                        ),
                      ),
                      child: const Icon(
                        Icons.person,
                        color: azulOscuro,
                        size: 27,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // CONTENIDO
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(12, 15, 12, 25),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      mesa == 0
                          ? 'PEDIDO'
                          : 'PEDIDO - MESA $mesa',
                      style: const TextStyle(
                        color: azulOscuro,
                        fontSize: 21,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 15),

                    if (pedido.isEmpty)
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                          vertical: 45,
                          horizontal: 20,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Column(
                          children: [
                            Icon(
                              Icons.shopping_cart_outlined,
                              color: azulOscuro,
                              size: 55,
                            ),
                            SizedBox(height: 15),
                            Text(
                              'Todavía no hay productos en el pedido.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 15,
                              ),
                            ),
                          ],
                        ),
                      )
                    else
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          children: [
                            ...pedido.asMap().entries.map(
                              (entry) {
                                final index = entry.key;
                                final item = entry.value;

                                final detalle =
                                    item['detalle'] as String;

                                return Container(
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 10,
                                    horizontal: 5,
                                  ),
                                  decoration: const BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        color: Color(0xFFE5E5E5),
                                      ),
                                    ),
                                  ),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        width: 48,
                                        height: 48,
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFE9F2F8),
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        child: const Icon(
                                          Icons.fastfood_outlined,
                                          color: azulOscuro,
                                          size: 25,
                                        ),
                                      ),

                                      const SizedBox(width: 10),

                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              '${item['cantidad']} × ${item['producto']}',
                                              style: const TextStyle(
                                                color: azulOscuro,
                                                fontSize: 15,
                                                fontWeight:
                                                    FontWeight.bold,
                                              ),
                                            ),

                                            if (detalle.isNotEmpty) ...[
                                              const SizedBox(height: 4),
                                              Text(
                                                detalle,
                                                style: const TextStyle(
                                                  color: Colors.grey,
                                                  fontSize: 12,
                                                ),
                                              ),
                                            ],

                                            const SizedBox(height: 5),

                                            Text(
                                              '\$ ${item['precio']}',
                                              style: const TextStyle(
                                                color: Colors.green,
                                                fontSize: 13,
                                                fontWeight:
                                                    FontWeight.bold,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),

                                      IconButton(
                                        onPressed: () {
                                          eliminarProducto(index);
                                        },
                                        icon: const Icon(
                                          Icons.delete_outline,
                                          color: Colors.red,
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),

                            const SizedBox(height: 15),

                            Row(
                              mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                              children: [
                                const Text(
                                  'TOTAL',
                                  style: TextStyle(
                                    color: azulOscuro,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  '\$ ${calcularTotal()}',
                                  style: const TextStyle(
                                    color: azulOscuro,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),

                            const SizedBox(height: 18),

                            SizedBox(
                              width: double.infinity,
                              height: 50,
                              child: ElevatedButton.icon(
                                onPressed: enviarPedido,
                                icon: const Icon(Icons.send),
                                label: const Text(
                                  'ENVIAR PEDIDO A COCINA',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: azulOscuro,
                                  foregroundColor: Colors.white,
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                        BorderRadius.circular(9),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
