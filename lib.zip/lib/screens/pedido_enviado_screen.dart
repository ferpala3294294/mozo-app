import 'package:flutter/material.dart';
import 'menu_screen.dart';

class PedidoEnviadoScreen extends StatelessWidget {
  final String mesa;
  final String producto;
  final int cantidad;
  final String observacion;

  const PedidoEnviadoScreen({
    super.key,
    required this.mesa,
    required this.producto,
    required this.cantidad,
    required this.observacion,
  });

  static const Color azulFondo = Color(0xFFEAF3F9);
  static const Color azulOscuro = Color(0xFF062D55);
  static const Color azul = Color(0xFF4E82A6);
  static const Color verde = Color(0xFF4CAF50);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: azulFondo,
      body: SafeArea(
        child: Column(
          children: [
            // =====================================================
            // BARRA SUPERIOR
            // =====================================================

            Container(
              height: 58,
              color: azulOscuro,
              child: Row(
                children: [
                  const SizedBox(width: 25),

                  const Expanded(
                    child: Center(
                      child: Text(
                        'Pedido enviado',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),

                  Container(
                    margin: const EdgeInsets.only(right: 15),
                    width: 39,
                    height: 39,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.white,
                        width: 2,
                      ),
                    ),
                    child: const Icon(
                      Icons.person,
                      color: Colors.white,
                      size: 27,
                    ),
                  ),
                ],
              ),
            ),

            // =====================================================
            // CONTENIDO
            // =====================================================

            Expanded(
              child: Stack(
                children: [
                  // =================================================
                  // DETALLES DECORATIVOS DEL FONDO
                  // =================================================

                  Positioned(
                    top: -80,
                    left: -70,
                    child: Container(
                      width: 220,
                      height: 220,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: azul.withOpacity(0.08),
                      ),
                    ),
                  ),

                  Positioned(
                    bottom: -100,
                    right: -70,
                    child: Container(
                      width: 250,
                      height: 250,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: azul.withOpacity(0.08),
                      ),
                    ),
                  ),

                  Positioned(
                    top: 100,
                    left: 55,
                    child: Icon(
                      Icons.auto_awesome,
                      size: 22,
                      color: azul.withOpacity(0.18),
                    ),
                  ),

                  Positioned(
                    top: 210,
                    right: 55,
                    child: Icon(
                      Icons.auto_awesome,
                      size: 18,
                      color: azul.withOpacity(0.16),
                    ),
                  ),

                  Positioned(
                    bottom: 120,
                    left: 75,
                    child: Icon(
                      Icons.auto_awesome,
                      size: 17,
                      color: azul.withOpacity(0.15),
                    ),
                  ),

                  // =================================================
                  // CONTENIDO PRINCIPAL
                  // =================================================

                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 25,
                      vertical: 25,
                    ),
                    child: Column(
                      children: [
                        const SizedBox(height: 35),

                        // =============================================
                        // CÍRCULO DE CONFIRMACIÓN
                        // =============================================

                        Container(
                          width: 130,
                          height: 130,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: verde,
                            boxShadow: [
                              BoxShadow(
                                color: verde.withOpacity(0.25),
                                blurRadius: 20,
                                spreadRadius: 5,
                              ),
                            ],
                          ),
                          child: Container(
                            margin: const EdgeInsets.all(7),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Colors.white.withOpacity(0.8),
                                width: 3,
                              ),
                            ),
                            child: const Icon(
                              Icons.check,
                              color: Colors.white,
                              size: 75,
                            ),
                          ),
                        ),

                        const SizedBox(height: 28),

                        // =============================================
                        // MESA
                        // =============================================

                        Text(
                          mesa.isEmpty ? 'Sin mesa' : mesa,
                          style: const TextStyle(
                            color: azulOscuro,
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        const SizedBox(height: 12),

                        // Línea decorativa
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 65,
                              height: 2,
                              color: azul.withOpacity(0.20),
                            ),
                            Container(
                              margin: const EdgeInsets.symmetric(
                                horizontal: 10,
                              ),
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: azul,
                              ),
                            ),
                            Container(
                              width: 65,
                              height: 2,
                              color: azul.withOpacity(0.20),
                            ),
                          ],
                        ),

                        const SizedBox(height: 25),

                        // =============================================
                        // MENSAJE
                        // =============================================

                        const Text(
                          '¡Tu pedido fue enviado\na cocina correctamente!',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: azulOscuro,
                            fontSize: 17,
                            fontWeight: FontWeight.w600,
                            height: 1.5,
                          ),
                        ),

                        const Spacer(),

                        // =============================================
                        // BOTÓN ENTENDIDO
                        // =============================================

                        SizedBox(
                          width: 150,
                          height: 50,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      const MenuScreen(),
                                ),
                                (route) => false,
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: azulOscuro,
                              foregroundColor: Colors.white,
                              elevation: 3,
                              shadowColor:
                                  azulOscuro.withOpacity(0.25),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: const Text(
                              'Entendido',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 25),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}