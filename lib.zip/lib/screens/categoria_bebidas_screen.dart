import '../producto_service.dart';
import 'login_screen.dart';
import 'package:flutter/material.dart';
import 'categoria_sandwiches_screen.dart';
import 'categoria_pizzas_screen.dart';
import 'categoria_empanadas_screen.dart';
import 'mesas_pedido_screen.dart';
import 'pedido_manager.dart';

class CategoriaBebidasScreen extends StatefulWidget {
  final int mesa;

  const CategoriaBebidasScreen({
    super.key,
    required this.mesa,
  });

  @override
  State<CategoriaBebidasScreen> createState() =>
      _CategoriaBebidasScreenState();
}

class _CategoriaBebidasScreenState extends State<CategoriaBebidasScreen> {
  String productoSeleccionado = '';

  static const Color azulOscuro = Color(0xFF174A75);
  static const Color azulBoton = Color(0xFF4E82A6);

  final PedidoManager pedidoManager = PedidoManager.instancia;

  List<Map<String, dynamic>> productos = [];
  bool cargandoProductos = true;
  String errorProductos = '';

  @override
  void initState() {
    super.initState();

    pedidoManager.addListener(actualizarCarrito);

    cargarProductos();
  }

  Future<void> cargarProductos() async {
    try {
      final datos = await ProductoService.obtenerProductos();

      if (!mounted) return;

      setState(() {
        productos = datos;
        cargandoProductos = false;
        errorProductos = '';
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        cargandoProductos = false;
        errorProductos = 'No se pudieron cargar los productos';
      });
    }
  }

  @override
  void dispose() {
    pedidoManager.removeListener(actualizarCarrito);
    super.dispose();
  }

  void actualizarCarrito() {
    if (mounted) {
      setState(() {});
    }
  }

  int convertirPrecio(String precio) {
    final limpio = precio
        .replaceAll('\$', '')
        .replaceAll('.', '')
        .replaceAll(',', '.')
        .trim();

    return double.parse(limpio).toInt();
  }

  String formatearPrecio(dynamic precio) {
    final numero = int.tryParse(precio.toString()) ?? 0;

    final texto = numero.toString();

    String resultado = '';
    int contador = 0;

    for (int i = texto.length - 1; i >= 0; i--) {
      resultado = texto[i] + resultado;
      contador++;

      if (contador == 3 && i != 0) {
        resultado = '.$resultado';
        contador = 0;
      }
    }

    return '\$$resultado,00';
  }

  Widget productosBebidas() {
    final gaseosas = productos.where((producto) {
      final categoria =
          (producto['categoria'] ?? '').toString().toLowerCase().trim();

      return categoria == 'gaseosas';
    }).toList();

    final cervezas = productos.where((producto) {
      final categoria =
          (producto['categoria'] ?? '').toString().toLowerCase().trim();

      return categoria == 'cervezas';
    }).toList();

    final aguas = productos.where((producto) {
      final categoria =
          (producto['categoria'] ?? '').toString().toLowerCase().trim();

      return categoria == 'aguas saborizadas';
    }).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (gaseosas.isNotEmpty) ...[
          tituloSeccion('Gaseosas'),
          filasDeProductos(gaseosas),
          const SizedBox(height: 8),
        ],

        if (cervezas.isNotEmpty) ...[
          tituloSeccion('Cervezas'),
          filasDeProductos(cervezas),
          const SizedBox(height: 8),
        ],

        if (aguas.isNotEmpty) ...[
          tituloSeccion('Aguas saborizadas'),
          filasDeProductos(aguas),
        ],

        if (gaseosas.isEmpty &&
            cervezas.isEmpty &&
            aguas.isEmpty)
          const Padding(
            padding: EdgeInsets.all(20),
            child: Center(
              child: Text(
                'No hay bebidas disponibles',
                style: TextStyle(
                  color: azulOscuro,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget filasDeProductos(
    List<Map<String, dynamic>> lista,
  ) {
    final List<Widget> filas = [];

    for (int i = 0; i < lista.length; i += 2) {
      final producto1 = lista[i];

      final Widget tarjeta1 = producto(
        nombre: producto1['nombre'].toString(),
        precio: formatearPrecio(producto1['precio']),
      );

      if (i + 1 < lista.length) {
        final producto2 = lista[i + 1];

        final Widget tarjeta2 = producto(
          nombre: producto2['nombre'].toString(),
          precio: formatearPrecio(producto2['precio']),
        );

        filas.add(
          filaProductos([
            tarjeta1,
            tarjeta2,
          ]),
        );
      } else {
        filas.add(
          Row(
            children: [
              Expanded(
                child: tarjeta1,
              ),
              const SizedBox(width: 20),
              const Expanded(
                child: SizedBox(),
              ),
            ],
          ),
        );
      }

      if (i + 2 < lista.length) {
        filas.add(
          const SizedBox(height: 8),
        );
      }
    }

    return Column(
      children: filas,
    );
  }

  void abrirPanelAgregarPedido({
    required String nombre,
    required String precio,
  }) {
    int cantidad = 1;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
              ),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(22),
                  ),
                ),
                child: SafeArea(
                  top: false,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'AGREGAR AL PEDIDO',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: azulOscuro,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: const Icon(
                                Icons.close,
                                color: azulOscuro,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 15),
                        Container(
                          height: 100,
                          decoration: BoxDecoration(
                            color: const Color(0xFFF1F1F1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 100,
                                height: double.infinity,
                                decoration: BoxDecoration(
                                  color: const Color(0xFFD8D8D8),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: const Icon(
                                  Icons.image_outlined,
                                  color: Colors.white,
                                  size: 40,
                                ),
                              ),
                              const SizedBox(width: 15),
                              Expanded(
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.center,
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      nombre,
                                      style: const TextStyle(
                                        color: azulOscuro,
                                        fontSize: 17,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      precio,
                                      style: const TextStyle(
                                        color: Colors.green,
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 15),
                        const Text(
                          'CANTIDAD',
                          style: TextStyle(
                            color: azulOscuro,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Container(
                          height: 50,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: azulBoton,
                            ),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: IconButton(
                                  onPressed: cantidad > 1
                                      ? () {
                                          setModalState(() {
                                            cantidad--;
                                          });
                                        }
                                      : null,
                                  icon: const Icon(
                                    Icons.remove,
                                    color: azulOscuro,
                                  ),
                                ),
                              ),
                              Expanded(
                                child: Center(
                                  child: Text(
                                    '$cantidad',
                                    style: const TextStyle(
                                      color: azulOscuro,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                              Expanded(
                                child: IconButton(
                                  onPressed: () {
                                    setModalState(() {
                                      cantidad++;
                                    });
                                  },
                                  icon: const Icon(
                                    Icons.add,
                                    color: azulOscuro,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          height: 48,
                          child: ElevatedButton.icon(
                            onPressed: () {
                              pedidoManager.agregarProducto(
                                mesa: widget.mesa,
                                producto: nombre,
                                categoria: 'Bebidas',
                                cantidad: cantidad,
                                precioUnitario:
                                    convertirPrecio(precio),
                                observacion: '',
                              );

                              Navigator.pop(context);

                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    '$cantidad x $nombre agregado al pedido',
                                  ),
                                  duration:
                                      const Duration(seconds: 2),
                                ),
                              );
                            },
                            icon: const Icon(Icons.add),
                            label: const Text(
                              'AGREGAR AL PEDIDO',
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: azulOscuro,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  void abrirPanelUsuario(BuildContext context) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Usuario',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 300),
      pageBuilder: (context, animation, secondaryAnimation) {
        return Align(
          alignment: Alignment.centerRight,
          child: Material(
            color: Colors.transparent,
            child: SizedBox(
              width: MediaQuery.of(context).size.width < 600
                  ? MediaQuery.of(context).size.width * 0.88
                  : 420,
              height: double.infinity,
              child: Container(
                color: Colors.white,
                child: SafeArea(
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerRight,
                        child: IconButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          icon: const Icon(
                            Icons.close,
                            color: azulOscuro,
                            size: 32,
                          ),
                        ),
                      ),
                      const SizedBox(height: 25),
                      Container(
                        width: 130,
                        height: 130,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFFE9E9E9),
                          border: Border.all(
                            color: azulOscuro,
                            width: 2,
                          ),
                        ),
                        child: const Icon(
                          Icons.person,
                          size: 85,
                          color: azulOscuro,
                        ),
                      ),
                      const SizedBox(height: 25),
                      const Text(
                        'Fernando Palavecino',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: azulOscuro,
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Mozo',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 20,
                        ),
                      ),
                      const SizedBox(height: 30),
                      const Divider(
                        thickness: 1,
                        indent: 30,
                        endIndent: 30,
                      ),
                      ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 35,
                          vertical: 8,
                        ),
                        leading: const Icon(
                          Icons.logout,
                          color: Colors.red,
                          size: 30,
                        ),
                        title: const Text(
                          'Cerrar sesión',
                          style: TextStyle(
                            color: Colors.red,
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        onTap: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  const LoginScreen(),
                            ),
                            (route) => false,
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (
        context,
        animation,
        secondaryAnimation,
        child,
      ) {
        final desplazamiento = Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(
          CurvedAnimation(
            parent: animation,
            curve: Curves.easeOut,
          ),
        );

        return SlideTransition(
          position: desplazamiento,
          child: child,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: SafeArea(
        child: Column(
          children: [
            // BARRA SUPERIOR
            Container(
              height: 67,
              color: Colors.white,
              child: Row(
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.arrow_back_ios_new,
                      color: azulOscuro,
                      size: 27,
                    ),
                  ),
                  const Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Categoría',
                          style: TextStyle(
                            color: azulOscuro,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Bebidas',
                          style: TextStyle(
                            color: azulOscuro,
                            fontSize: 19,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // CARRITO
                  Stack(
                    clipBehavior: Clip.none,
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  const MesasPedidoScreen(),
                            ),
                          );
                        },
                        icon: const Icon(
                          Icons.shopping_cart_outlined,
                          color: azulOscuro,
                          size: 28,
                        ),
                      ),
                      if (pedidoManager.cantidadProductos > 0)
                        Positioned(
                          right: 2,
                          top: 0,
                          child: Container(
                            constraints: const BoxConstraints(
                              minWidth: 18,
                              minHeight: 18,
                            ),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 4,
                            ),
                            decoration: BoxDecoration(
                              color: azulOscuro,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Colors.white,
                                width: 1.5,
                              ),
                            ),
                            child: Center(
                              child: Text(
                                '${pedidoManager.cantidadProductos}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),

                  // USUARIO
                  GestureDetector(
                    onTap: () {
                      abrirPanelUsuario(context);
                    },
                    child: Container(
                      margin: const EdgeInsets.only(
                        left: 5,
                        right: 12,
                      ),
                      width: 39,
                      height: 39,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: azulOscuro,
                          width: 2,
                        ),
                      ),
                      child: const Icon(
                        Icons.person,
                        color: azulOscuro,
                        size: 27,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // CONTENIDO
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(
                  7,
                  8,
                  7,
                  20,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // BOTONES DE CATEGORÍAS
                    Row(
                      children: [
                        // SANDWICHES
                        categoriaBoton(
                          icono: Icons.lunch_dining,
                          onTap: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    CategoriaSandwichesScreen(
                                  mesa: widget.mesa,
                                ),
                              ),
                            );
                          },
                        ),

                        const SizedBox(width: 14),

                        // PIZZAS
                        categoriaBoton(
                          icono: Icons.local_pizza,
                          onTap: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    CategoriaPizzasScreen(
                                  mesa: widget.mesa,
                                ),
                              ),
                            );
                          },
                        ),

                        const SizedBox(width: 14),

                        // EMPANADAS
                        categoriaBoton(
                          icono: Icons.bakery_dining,
                          onTap: () {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    CategoriaEmpanadasScreen(
                                  mesa: widget.mesa,
                                ),
                              ),
                            );
                          },
                        ),

                        const SizedBox(width: 14),

                        // BEBIDAS
                        categoriaBoton(
                          icono: Icons.local_drink,
                          onTap: () {},
                        ),
                      ],
                    ),

                    const SizedBox(height: 10),

                    // PRODUCTOS DESDE LARAVEL
                    if (cargandoProductos)
                      const Center(
                        child: Padding(
                          padding: EdgeInsets.all(30),
                          child: CircularProgressIndicator(),
                        ),
                      )
                    else if (errorProductos.isNotEmpty)
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.all(30),
                          child: Text(
                            errorProductos,
                            style: const TextStyle(
                              color: Colors.red,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      )
                    else
                      productosBebidas(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget categoriaBoton({
    required IconData icono,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 25,
          decoration: BoxDecoration(
            color: azulBoton,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Center(
            child: Icon(
              icono,
              color: Colors.white,
              size: 18,
            ),
          ),
        ),
      ),
    );
  }

  Widget tituloSeccion(String texto) {
    return Padding(
      padding: const EdgeInsets.only(
        left: 1,
        bottom: 5,
      ),
      child: Text(
        texto,
        style: const TextStyle(
          color: azulOscuro,
          fontSize: 17,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget filaProductos(List<Widget> productos) {
    return Row(
      children: [
        Expanded(
          child: productos[0],
        ),
        const SizedBox(width: 20),
        Expanded(
          child: productos[1],
        ),
      ],
    );
  }

  Widget producto({
    required String nombre,
    required String precio,
  }) {
    final seleccionado = productoSeleccionado == nombre;

    return GestureDetector(
      onTap: () {
        setState(() {
          productoSeleccionado = nombre;
        });

        abrirPanelAgregarPedido(
          nombre: nombre,
          precio: precio,
        );
      },
      child: Container(
        height: 87,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(9),
          border: Border.all(
            color: seleccionado
                ? Colors.blue
                : Colors.transparent,
            width: seleccionado ? 2 : 1,
          ),
          boxShadow: const [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 3,
              offset: Offset(0, 1),
            ),
          ],
        ),
        child: Column(
          children: [
            Expanded(
              child: Container(
                margin: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  color: const Color(0xFFD8D8D8),
                  borderRadius: BorderRadius.circular(7),
                ),
                child: const Center(
                  child: Icon(
                    Icons.image_outlined,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.only(left: 5),
                child: Text(
                  nombre,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 7,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.only(
                  left: 5,
                  bottom: 3,
                ),
                child: Text(
                  precio,
                  style: const TextStyle(
                    color: Colors.green,
                    fontSize: 6,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}