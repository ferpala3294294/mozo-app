import 'package:flutter/material.dart';
import 'pedido_enviado_screen.dart';
import 'pedido_manager.dart';
import 'detalle.dart';

class ConfirmarPedidoScreen extends StatefulWidget {
  final String mesa;
  final List<Map<String, dynamic>> pedido;

  const ConfirmarPedidoScreen({
    super.key,
    required this.mesa,
    required this.pedido,
  });

  @override
  State<ConfirmarPedidoScreen> createState() =>
      _ConfirmarPedidoScreenState();
}

class _ConfirmarPedidoScreenState
    extends State<ConfirmarPedidoScreen> {
  late List<Map<String, dynamic>> pedido;

  final PedidoManager pedidoManager =
      PedidoManager.instancia;

  static const Color azulOscuro = Color(0xFF062D55);
  static const Color azulBoton = Color(0xFF4E82A6);

  @override
  void initState() {
    super.initState();

    pedido = List<Map<String, dynamic>>.from(
      widget.pedido,
    );
  }

  int calcularTotal() {
    int total = 0;

    for (final item in pedido) {
      total += item['precio'] as int;
    }

    return total;
  }

  // ----------------------------------------------------------
  // PRECIOS DE LOS PRODUCTOS
  // ----------------------------------------------------------

  final Map<String, Map<String, int>> preciosProductos = {
    'Sandwiches': {
      'Hamburguesa Simple': 10000,
      'Hamburguesa Mexicana': 8500,
      'Lomito Simple': 15000,
      'Lomito Completo': 17000,
      'Charly': 15000,
      'Suizo': 16000,
    },

    'Empanadas': {
      'Empanada de Carne': 7500,
      'Empanada de Matambre': 15500,
      'Empanada de Pescado': 12500,
      'Empanada de Pollo': 15500,
      'Empanada de Queso con Espinaca': 19500,
    },

    'Pizzas': {
      'Pizza Especial': 5500,
      'Pizza Simple': 7500,
      'Pizza Americana': 10500,
      'Pizza con Pepperoni': 11000,
      'Pizza Mexicana': 10500,
    },

    'Bebidas': {
      'Coca-Cola': 3000,
      'Pepsi': 2800,
      'Quilmes': 4500,
      'Stella Artois': 5500,
      'Levité': 2500,
      'Aquarius': 2700,
    },
  };

  // ----------------------------------------------------------
  // ELIMINAR
  // ----------------------------------------------------------

  void eliminarProducto(int index) {
    if (index < 0 || index >= pedido.length) return;

    final item = pedido[index];

    setState(() {
      pedido.removeAt(index);
    });

    pedidoManager.eliminarProductoItem(item);
  }

  // ----------------------------------------------------------
  // EDITAR PRODUCTO
  // ----------------------------------------------------------

  void editarProducto(
    int index,
    Map<String, dynamic> item,
  ) {
    String productoSeleccionado =
        item['producto'] as String;

    int cantidad =
        item['cantidad'] as int;

    String observacion =
        item['detalle'] as String;

    final categoria =
        item['categoria'] as String;

    final productosCategoria =
        preciosProductos[categoria] ??
            <String, int>{
              productoSeleccionado:
                  item['precioUnitario'] as int,
            };

    final observacionController =
        TextEditingController(
      text: observacion,
    );

    showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (
            context,
            setDialogState,
          ) {
            final precioActual =
                productosCategoria[
                        productoSeleccionado] ??
                    item['precioUnitario']
                        as int;

            return AlertDialog(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(15),
              ),

              title: const Row(
                children: [
                  Icon(
                    Icons.edit,
                    color: azulOscuro,
                  ),
                  SizedBox(width: 10),
                  Text(
                    'Modificar producto',
                    style: TextStyle(
                      color: azulOscuro,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),

              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [

                    // PRODUCTO
                    const Text(
                      'PRODUCTO',
                      style: TextStyle(
                        color: azulOscuro,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 7),

                    DropdownButtonFormField<String>(
                      value: productosCategoria
                              .containsKey(
                                  productoSeleccionado)
                          ? productoSeleccionado
                          : productosCategoria
                              .keys
                              .first,

                      decoration:
                          InputDecoration(
                        border:
                            OutlineInputBorder(
                          borderRadius:
                              BorderRadius.circular(
                            8,
                          ),
                        ),
                        focusedBorder:
                            OutlineInputBorder(
                          borderRadius:
                              BorderRadius.circular(
                            8,
                          ),
                          borderSide:
                              const BorderSide(
                            color: azulOscuro,
                            width: 2,
                          ),
                        ),
                      ),

                      items: productosCategoria
                          .keys
                          .map(
                        (producto) {
                          return DropdownMenuItem<
                              String>(
                            value: producto,
                            child: Text(
                              producto,
                            ),
                          );
                        },
                      ).toList(),

                      onChanged: (valor) {
                        if (valor == null) return;

                        setDialogState(() {
                          productoSeleccionado =
                              valor;
                        });
                      },
                    ),

                    const SizedBox(height: 18),

                    // PRECIO
                    Text(
                      'PRECIO UNITARIO: \$ $precioActual',
                      style: const TextStyle(
                        color: Colors.green,
                        fontWeight:
                            FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 18),

                    // CANTIDAD
                    const Text(
                      'CANTIDAD',
                      style: TextStyle(
                        color: azulOscuro,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 7),

                    Container(
                      height: 50,
                      decoration:
                          BoxDecoration(
                        border: Border.all(
                          color: azulBoton,
                        ),
                        borderRadius:
                            BorderRadius.circular(
                          8,
                        ),
                      ),
                      child: Row(
                        children: [

                          Expanded(
                            child: IconButton(
                              onPressed:
                                  cantidad > 1
                                      ? () {
                                          setDialogState(
                                            () {
                                              cantidad--;
                                            },
                                          );
                                        }
                                      : null,
                              icon:
                                  const Icon(
                                Icons.remove,
                                color: azulOscuro,
                              ),
                            ),
                          ),

                          Expanded(
                            child: Center(
                              child: Text(
                                '$cantidad',
                                style:
                                    const TextStyle(
                                  color:
                                      azulOscuro,
                                  fontSize: 20,
                                  fontWeight:
                                      FontWeight.bold,
                                ),
                              ),
                            ),
                          ),

                          Expanded(
                            child: IconButton(
                              onPressed: () {
                                setDialogState(
                                  () {
                                    cantidad++;
                                  },
                                );
                              },
                              icon:
                                  const Icon(
                                Icons.add,
                                color: azulOscuro,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 18),

                    // OBSERVACIÓN
                    const Text(
                      'DETALLE / OBSERVACIÓN',
                      style: TextStyle(
                        color: azulOscuro,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 7),

                    TextField(
                      controller:
                          observacionController,
                      maxLines: 3,

                      decoration:
                          InputDecoration(
                        hintText:
                            'Ej: Sin cebolla, sin tomate...',
                        border:
                            OutlineInputBorder(
                          borderRadius:
                              BorderRadius.circular(
                            8,
                          ),
                        ),
                        focusedBorder:
                            OutlineInputBorder(
                          borderRadius:
                              BorderRadius.circular(
                            8,
                          ),
                          borderSide:
                              const BorderSide(
                            color: azulOscuro,
                            width: 2,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              actions: [

                // CANCELAR
                TextButton(
                  onPressed: () {
                    Navigator.pop(
                      dialogContext,
                    );
                  },

                  child: const Text(
                    'CANCELAR',
                    style: TextStyle(
                      color: azulOscuro,
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),
                ),

                // GUARDAR
                ElevatedButton(
                  onPressed: () {
                    final nuevoPrecio =
                        productosCategoria[
                                productoSeleccionado] ??
                            precioActual;

                    pedidoManager
                        .actualizarProducto(
                      item: item,
                      producto:
                          productoSeleccionado,
                      cantidad: cantidad,
                      precioUnitario:
                          nuevoPrecio,
                      observacion:
                          observacionController
                              .text
                              .trim(),
                    );

                    setState(() {
                      pedido[index]['producto'] =
                          productoSeleccionado;

                      pedido[index]['cantidad'] =
                          cantidad;

                      pedido[index]
                              ['precioUnitario'] =
                          nuevoPrecio;

                      pedido[index]['precio'] =
                          nuevoPrecio * cantidad;

                      pedido[index]['detalle'] =
                          observacionController
                              .text
                              .trim();
                    });

                    Navigator.pop(
                      dialogContext,
                    );
                  },

                  style:
                      ElevatedButton.styleFrom(
                    backgroundColor:
                        azulOscuro,
                    foregroundColor:
                        Colors.white,
                    shape:
                        RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(
                        8,
                      ),
                    ),
                  ),

                  child: const Text(
                    'GUARDAR',
                    style: TextStyle(
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),
                ),
              ],
            );
          },
        );
      },
    ).whenComplete(() {
      observacionController.dispose();
    });
  }

  // ----------------------------------------------------------
  // ENVIAR
  // ----------------------------------------------------------

  void enviarPedido() {
    if (pedido.isEmpty) {
      return;
    }

    // ========================================================
    // IMPORTANTE:
    // El pedido pasa a estar ENVIADO solamente cuando
    // el usuario presiona el botón ENVIAR.
    // ========================================================

    final numeroMesa = int.tryParse(
      widget.mesa.replaceAll(
        RegExp(r'[^0-9]'),
        '',
      ),
    );

    if (numeroMesa != null) {
      DetalleScreen.marcarPedidoEnviado(
        numeroMesa,
      );
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            PedidoEnviadoScreen(
          mesa: widget.mesa,
          producto: 'Pedido completo',
          cantidad: pedido.length,
          observacion: '',
        ),
      ),
    );
  }

  // ----------------------------------------------------------
  // BUILD
  // ----------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          const Color(0xFFE9E9E9),

      // ------------------------------------------------------
      // BARRA SUPERIOR
      // ------------------------------------------------------

      appBar: AppBar(
        backgroundColor:
            azulOscuro,

        elevation: 0,

        centerTitle: true,

        automaticallyImplyLeading:
            false,

        title: const Text(
          'Confirmar Pedido',
          style: TextStyle(
            color: Colors.white,
            fontWeight:
                FontWeight.bold,
          ),
        ),
      ),

      body: SafeArea(
        child: Column(
          children: [

            Expanded(
              child:
                  SingleChildScrollView(
                padding:
                    const EdgeInsets.all(
                  16,
                ),

                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,

                  children: [

                    // ------------------------------------------------
                    // MESA
                    // ------------------------------------------------

                    const Text(
                      'MESA:',
                      style: TextStyle(
                        color: azulOscuro,
                        fontSize: 18,
                        fontWeight:
                            FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 8),

                    Container(
                      padding:
                          const EdgeInsets
                              .symmetric(
                        horizontal: 20,
                        vertical: 10,
                      ),

                      decoration:
                          BoxDecoration(
                        color: azulOscuro,
                        borderRadius:
                            BorderRadius.circular(
                          8,
                        ),
                      ),

                      child: Text(
                        widget.mesa.isEmpty
                            ? 'Sin mesa'
                            : widget.mesa,

                        style:
                            const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight:
                              FontWeight.bold,
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),

                    // ------------------------------------------------
                    // PEDIDO
                    // ------------------------------------------------

                    const Text(
                      'PEDIDO:',
                      style: TextStyle(
                        color: azulOscuro,
                        fontSize: 18,
                        fontWeight:
                            FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 12),

                    if (pedido.isEmpty)
                      const Center(
                        child: Padding(
                          padding:
                              EdgeInsets.only(
                            top: 30,
                          ),
                          child: Text(
                            'No hay productos en el pedido',
                            style:
                                TextStyle(
                              color:
                                  Colors.grey,
                              fontSize: 16,
                              fontWeight:
                                  FontWeight.bold,
                            ),
                          ),
                        ),
                      )
                    else
                      ...pedido
                          .asMap()
                          .entries
                          .map(
                        (entry) {
                          final index =
                              entry.key;

                          final item =
                              entry.value;

                          return _producto(
                            index,
                            item,
                          );
                        },
                      ),

                    const SizedBox(height: 20),

                    // ------------------------------------------------
                    // TOTAL
                    // ------------------------------------------------

                    Row(
                      mainAxisAlignment:
                          MainAxisAlignment
                              .spaceBetween,

                      children: [

                        const Text(
                          'TOTAL:',
                          style: TextStyle(
                            color: azulOscuro,
                            fontSize: 18,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),

                        Text(
                          '\$ ${calcularTotal()}',
                          style:
                              const TextStyle(
                            color: azulOscuro,
                            fontSize: 20,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            // ------------------------------------------------------
            // BOTONES
            // ------------------------------------------------------

            Padding(
              padding:
                  const EdgeInsets.fromLTRB(
                12,
                8,
                12,
                18,
              ),

              child: Row(
                children: [

                  Expanded(
                    child:
                        OutlinedButton(
                      onPressed: () {
                        Navigator.pop(
                          context,
                        );
                      },

                      style:
                          OutlinedButton
                              .styleFrom(
                        minimumSize:
                            const Size(
                          0,
                          45,
                        ),

                        side:
                            const BorderSide(
                          color: azulOscuro,
                          width: 2,
                        ),

                        shape:
                            RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius
                                  .circular(
                            20,
                          ),
                        ),
                      ),

                      child:
                          const Text(
                        'CANCELAR',
                        style:
                            TextStyle(
                          color:
                              azulOscuro,
                          fontWeight:
                              FontWeight
                                  .bold,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(width: 10),

                  Expanded(
                    child:
                        ElevatedButton(
                      onPressed:
                          pedido.isEmpty
                              ? null
                              : enviarPedido,

                      style:
                          ElevatedButton
                              .styleFrom(
                        backgroundColor:
                            azulOscuro,

                        foregroundColor:
                            Colors.white,

                        minimumSize:
                            const Size(
                          0,
                          45,
                        ),

                        shape:
                            RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius
                                  .circular(
                            20,
                          ),
                        ),
                      ),

                      child:
                          const Text(
                        'ENVIAR',
                        style:
                            TextStyle(
                          fontWeight:
                              FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ----------------------------------------------------------
  // TARJETA DEL PRODUCTO
  // ----------------------------------------------------------

  Widget _producto(
    int index,
    Map<String, dynamic> item,
  ) {
    final detalle =
        item['detalle'] as String;

    return Container(
      width: double.infinity,

      margin:
          const EdgeInsets.only(
        bottom: 10,
      ),

      padding:
          const EdgeInsets.all(14),

      decoration: BoxDecoration(
        color: azulBoton,

        borderRadius:
            BorderRadius.circular(10),

        border: Border.all(
          color: azulOscuro,
          width: 1,
        ),
      ),

      child: Row(
        children: [

          // CANTIDAD
          Container(
            width: 55,
            height: 55,

            alignment:
                Alignment.center,

            decoration:
                BoxDecoration(
              color: azulOscuro,

              borderRadius:
                  BorderRadius.circular(8),
            ),

            child: Text(
              item['cantidad'].toString(),

              style:
                  const TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight:
                    FontWeight.bold,
              ),
            ),
          ),

          const SizedBox(width: 12),

          const Text(
            '×',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight:
                  FontWeight.bold,
            ),
          ),

          const SizedBox(width: 12),

          // PRODUCTO + OBSERVACIÓN
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [

                Text(
                  item['producto'],

                  style:
                      const TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 4),

                Text(
                  detalle.isEmpty
                      ? 'Sin observaciones'
                      : detalle,

                  style:
                      const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontStyle:
                        FontStyle.italic,
                  ),
                ),
              ],
            ),
          ),

          // LÁPIZ
          IconButton(
            tooltip: 'Modificar',
            onPressed: () {
              editarProducto(
                index,
                item,
              );
            },

            icon: const Icon(
              Icons.edit,
              color: Colors.white,
            ),
          ),

          // TACHO
          IconButton(
            tooltip: 'Eliminar',
            onPressed: () {
              eliminarProducto(index);
            },

            icon: const Icon(
              Icons.delete,
              color: Colors.red,
            ),
          ),
        ],
      ),
    );
  }
}