import 'package:flutter/material.dart';
import 'pedido_manager.dart';
import 'categorias_screen.dart';
import 'login_screen.dart';

class DetalleScreen extends StatefulWidget {
  final int mesa;

  const DetalleScreen({
    super.key,
    required this.mesa,
  });

  // =====================================================
  // MESAS QUE YA ENVIARON EL PEDIDO
  // =====================================================
  static final Set<int> mesasConPedidoEnviado = {};

  static void marcarPedidoEnviado(int mesa) {
    mesasConPedidoEnviado.add(mesa);
  }

  @override
  State<DetalleScreen> createState() => _DetalleScreenState();
}

class _DetalleScreenState extends State<DetalleScreen> {
  static const Color azulOscuro = Color(0xFF062D55);
  static const Color azul = Color(0xFF4F86AE);
  static const Color fondo = Color(0xFFF5F9FC);
  static const Color azulMuyClaro = Color(0xFFEAF3FA);

  final PedidoManager pedidoManager = PedidoManager.instancia;

  @override
  void initState() {
    super.initState();
    pedidoManager.addListener(actualizarPantalla);
  }

  @override
  void dispose() {
    pedidoManager.removeListener(actualizarPantalla);
    super.dispose();
  }

  void actualizarPantalla() {
    if (mounted) {
      setState(() {});
    }
  }

  // =====================================================
  // PANEL DE USUARIO
  // =====================================================
  void abrirPanelUsuario(BuildContext context) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Perfil',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 300),
      pageBuilder: (context, animation, secondaryAnimation) {
        return Align(
          alignment: Alignment.centerRight,
          child: Material(
            color: Colors.transparent,
            child: LayoutBuilder(
              builder: (context, constraints) {
                final anchoPantalla = constraints.maxWidth;

                final anchoPanel = anchoPantalla < 600
                    ? anchoPantalla * 0.88
                    : 420.0;

                return SizedBox(
                  width: anchoPanel,
                  height: double.infinity,
                  child: Container(
                    color: Colors.white,
                    child: SafeArea(
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Align(
                              alignment: Alignment.centerRight,
                              child: IconButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                icon: const Icon(
                                  Icons.close,
                                  color: Color(0xFF174A75),
                                  size: 32,
                                ),
                              ),
                            ),

                            const SizedBox(height: 25),

                            Container(
                              width: 130,
                              height: 130,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xFFE9E9E9),
                                border: Border.all(
                                  color: const Color(0xFF174A75),
                                  width: 2,
                                ),
                              ),
                              child: const Icon(
                                Icons.person,
                                size: 85,
                                color: Color(0xFF174A75),
                              ),
                            ),

                            const SizedBox(height: 25),

                            const Text(
                              'Fernando Palavecino',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Color(0xFF174A75),
                                fontSize: 26,
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            const SizedBox(height: 8),

                            const Text(
                              'Mozo',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 20,
                              ),
                            ),

                            const SizedBox(height: 30),

                            const Divider(
                              thickness: 1,
                              indent: 30,
                              endIndent: 30,
                            ),

                            ListTile(
                              contentPadding:
                                  const EdgeInsets.symmetric(
                                horizontal: 35,
                                vertical: 8,
                              ),
                              leading: const Icon(
                                Icons.logout,
                                color: Colors.red,
                                size: 30,
                              ),
                              title: const Text(
                                'Cerrar sesión',
                                style: TextStyle(
                                  color: Colors.red,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              onTap: () {
                                Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const LoginScreen(),
                                  ),
                                  (route) => false,
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
      transitionBuilder: (
        context,
        animation,
        secondaryAnimation,
        child,
      ) {
        final desplazamiento = Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(
          CurvedAnimation(
            parent: animation,
            curve: Curves.easeOut,
          ),
        );

        return SlideTransition(
          position: desplazamiento,
          child: child,
        );
      },
    );
  }

  // =====================================================
  // ¿EL PEDIDO DE ESTA MESA YA FUE ENVIADO?
  // =====================================================
  bool get pedidoFueEnviado {
    return DetalleScreen.mesasConPedidoEnviado.contains(
      widget.mesa,
    );
  }

  // =====================================================
  // PRODUCTOS DE ESTA MESA
  // =====================================================
  List<Map<String, dynamic>> get pedidoMesa {
    // Si todavía NO fue enviado, no mostramos los productos
    // como detalle del pedido enviado.
    if (!pedidoFueEnviado) {
      return [];
    }

    return pedidoManager.pedido
        .where((item) => item['mesa'] == widget.mesa)
        .toList();
  }

  int get totalMesa {
    int total = 0;

    for (final item in pedidoMesa) {
      total += item['precio'] as int;
    }

    return total;
  }

  int get cantidadMesa {
    int cantidad = 0;

    for (final item in pedidoMesa) {
      cantidad += item['cantidad'] as int;
    }

    return cantidad;
  }

  String formatoPrecio(int precio) {
    return '\$${precio.toString().replaceAllMapped(
          RegExp(r'(\d)(?=(\d{3})+(?!\d))'),
          (match) => '${match.group(1)}.',
        )},00';
  }

  IconData iconoCategoria(String categoria) {
    switch (categoria) {
      case 'Sandwiches':
        return Icons.lunch_dining;
      case 'Pizzas':
        return Icons.local_pizza;
      case 'Empanadas':
        return Icons.bakery_dining;
      case 'Bebidas':
        return Icons.local_drink;
      default:
        return Icons.restaurant;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: fondo,
      body: SafeArea(
        child: Column(
          children: [
            // =====================================================
            // BARRA SUPERIOR
            // =====================================================
            Container(
              height: 62,
              color: azulOscuro,
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Row(
                children: [
                  // USUARIO
                  IconButton(
                    onPressed: () {
                      abrirPanelUsuario(context);
                    },
                    icon: const Icon(
                      Icons.person,
                      color: Colors.white,
                      size: 28,
                    ),
                  ),

                  Expanded(
                    child: Column(
                      mainAxisAlignment:
                          MainAxisAlignment.center,
                      children: [
                        const Text(
                          'Detalle del pedido',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        
                      ],
                    ),
                  ),

                  // NOTIFICACIONES
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(
                      Icons.notifications,
                      color: Colors.white,
                      size: 27,
                    ),
                  ),
                ],
              ),
            ),

            // =====================================================
            // CONTENIDO
            // =====================================================
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(
                  12,
                  12,
                  12,
                  20,
                ),
                child: Column(
                  children: [
                    // =================================================
                    // INFORMACIÓN DE LA MESA
                    // =================================================
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: azulMuyClaro,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 48,
                            height: 48,
                            decoration: const BoxDecoration(
                              color: azulOscuro,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.table_restaurant,
                              color: Colors.white,
                              size: 26,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Text(
                            'Mesa ${widget.mesa}',
                            style: const TextStyle(
                              color: azulOscuro,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 14),

                    // =================================================
                    // ENCABEZADO RESUMEN
                    // =================================================
                    Row(
                      children: [
                        Container(
                          width: 38,
                          height: 38,
                          decoration: const BoxDecoration(
                            color: azulOscuro,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.receipt_long,
                            color: Colors.white,
                            size: 21,
                          ),
                        ),
                        const SizedBox(width: 10),

                        const Expanded(
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Resumen del pedido',
                                style: TextStyle(
                                  color: azulOscuro,
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                'Productos agregados',
                                style: TextStyle(
                                  color: azul,
                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                        ),

                        Container(
                          padding:
                              const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 7,
                          ),
                          decoration: BoxDecoration(
                            color: azulOscuro,
                            borderRadius:
                                BorderRadius.circular(6),
                          ),
                          child: Text(
                            '$cantidadMesa productos',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 12),

                    // =================================================
                    // PRODUCTOS
                    // =================================================
                    if (!pedidoFueEnviado)
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                          vertical: 35,
                        ),
                        child: const Column(
                          children: [
                            Icon(
                              Icons.pending_actions,
                              color: Colors.grey,
                              size: 50,
                            ),
                            SizedBox(height: 10),
                            Text(
                              'El pedido todavía no fue enviado.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 13,
                              ),
                            ),
                            SizedBox(height: 5),
                            Text(
                              'Los productos aparecerán aquí cuando se envíe.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),

                    if (pedidoFueEnviado && pedidoMesa.isEmpty)
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                          vertical: 35,
                        ),
                        child: const Column(
                          children: [
                            Icon(
                              Icons.shopping_cart_outlined,
                              color: Colors.grey,
                              size: 50,
                            ),
                            SizedBox(height: 10),
                            Text(
                              'No hay productos para esta mesa.',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),

                    if (pedidoFueEnviado)
                      ...pedidoMesa.map(
                        (item) {
                          final categoria =
                              item['categoria'] as String? ?? '';

                          final detalle =
                              item['detalle'] as String? ?? '';

                          return Container(
                            width: double.infinity,
                            margin: const EdgeInsets.only(
                              bottom: 7,
                            ),
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius:
                                  BorderRadius.circular(8),
                              border: Border.all(
                                color:
                                    const Color(0xFFE5E5E5),
                              ),
                            ),
                            child: Row(
                              children: [
                                // ICONO
                                Container(
                                  width: 42,
                                  height: 42,
                                  decoration:
                                      const BoxDecoration(
                                    color: azulMuyClaro,
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    iconoCategoria(categoria),
                                    color: azulOscuro,
                                    size: 22,
                                  ),
                                ),

                                const SizedBox(width: 10),

                                // INFORMACIÓN
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        item['producto'],
                                        maxLines: 1,
                                        overflow:
                                            TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: azulOscuro,
                                          fontSize: 13,
                                          fontWeight:
                                              FontWeight.bold,
                                        ),
                                      ),

                                      const SizedBox(height: 3),

                                      Text(
                                        'Cantidad: ${item['cantidad']}',
                                        style:
                                            const TextStyle(
                                          color: azulOscuro,
                                          fontSize: 10,
                                        ),
                                      ),

                                      if (detalle.isNotEmpty) ...[
                                        const SizedBox(height: 2),
                                        Text(
                                          detalle,
                                          maxLines: 1,
                                          overflow:
                                              TextOverflow
                                                  .ellipsis,
                                          style:
                                              const TextStyle(
                                            color: Colors.grey,
                                            fontSize: 9,
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                ),

                                const SizedBox(width: 8),

                                // PRECIO
                                Text(
                                  formatoPrecio(
                                    item['precio'] as int,
                                  ),
                                  style: const TextStyle(
                                    color: azulOscuro,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),

                    const SizedBox(height: 4),

                    // =================================================
                    // AGREGAR MÁS PRODUCTOS
                    // =================================================
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                CategoriasScreen(
                              mesa: widget.mesa,
                            ),
                          ),
                        );
                      },
                      child: Container(
                        width: double.infinity,
                        padding:
                            const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                              BorderRadius.circular(8),
                          border: Border.all(
                            color: azul,
                            style: BorderStyle.solid,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 32,
                              height: 32,
                              decoration:
                                  const BoxDecoration(
                                color: azulOscuro,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                                size: 21,
                              ),
                            ),

                            const SizedBox(width: 10),

                            const Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Agregar más productos',
                                    style: TextStyle(
                                      color: azulOscuro,
                                      fontSize: 12,
                                      fontWeight:
                                          FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    'Volver a las categorías',
                                    style: TextStyle(
                                      color: azul,
                                      fontSize: 9,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            const Icon(
                              Icons.chevron_right,
                              color: azulOscuro,
                              size: 26,
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    // =================================================
                    // TOTAL
                    // =================================================
                    Container(
                      width: double.infinity,
                      padding:
                          const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 13,
                      ),
                      decoration: BoxDecoration(
                        color: azulMuyClaro,
                        borderRadius:
                            BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          const Expanded(
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Total del pedido',
                                  style: TextStyle(
                                    color: azulOscuro,
                                    fontSize: 13,
                                    fontWeight:
                                        FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 3),
                                Text(
                                  'Productos agregados',
                                  style: TextStyle(
                                    color: azul,
                                    fontSize: 9,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          Text(
                            formatoPrecio(totalMesa),
                            style: const TextStyle(
                              color: azulOscuro,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}