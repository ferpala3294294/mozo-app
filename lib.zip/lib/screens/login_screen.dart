import 'package:flutter/material.dart';
import 'menu_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  bool ocultarPassword = true;

  static const Color azulOscuro = Color(0xFF12345A);
  static const Color azul = Color(0xFF4F86AE);
  static const Color azulClaro = Color(0xFFB5D3E8);

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  void iniciarSesion() {
    if (emailController.text.isEmpty ||
        passwordController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Completá el usuario y la contraseña'),
        ),
      );
      return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => const MenuScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final anchoPantalla = MediaQuery.of(context).size.width;

    // En PC limitamos el ancho para que no quede estirado.
    // En celular ocupa casi todo el ancho disponible.
    final double anchoFormulario = anchoPantalla >= 700
        ? 620
        : anchoPantalla * 0.88;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Stack(
          children: [
            // CÍRCULOS SUPERIORES
            Positioned(
              top: 10,
              left: -18,
              child: circulo(57, azulOscuro),
            ),

            Positioned(
              top: 36,
              left: anchoPantalla < 500 ? 105 : 120,
              child: circulo(
                anchoPantalla < 500 ? 29 : 32,
                const Color(0xFFF0F5F9),
              ),
            ),

            Positioned(
              top: 64,
              left: anchoPantalla < 500 ? 74 : 90,
              child: circulo(
                anchoPantalla < 500 ? 34 : 38,
                azul,
              ),
            ),

            // CÍRCULOS INFERIORES
            Positioned(
              bottom: 65,
              right: 27,
              child: circulo(34, azul),
            ),

            Positioned(
              bottom: 12,
              right: -2,
              child: circulo(27, azulClaro),
            ),

            Positioned(
              top: 430,
              right: -13,
              child: circulo(55, azulOscuro),
            ),

            // CONTENIDO CENTRAL
            Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 30,
                ),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: anchoFormulario,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // TÍTULO
                      Text(
                        'BIENVENIDOS',
                        style: TextStyle(
                          color: azulOscuro,
                          fontSize: anchoPantalla < 400 ? 24 : 27,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.3,
                        ),
                      ),

                      SizedBox(
                        height: anchoPantalla < 400 ? 32 : 38,
                      ),

                      // USUARIO
                      campo(
                        controller: emailController,
                        hint: 'Usuario',
                        ocultar: false,
                      ),

                      const SizedBox(height: 12),

                      // CONTRASEÑA
                      campo(
                        controller: passwordController,
                        hint: 'Contraseña',
                        ocultar: ocultarPassword,
                        sufijo: IconButton(
                          onPressed: () {
                            setState(() {
                              ocultarPassword = !ocultarPassword;
                            });
                          },
                          icon: Icon(
                            ocultarPassword
                                ? Icons.visibility_off_outlined
                                : Icons.visibility_outlined,
                            size: anchoPantalla < 400 ? 20 : 22,
                            color: Colors.grey.shade700,
                          ),
                        ),
                      ),

                      SizedBox(
                        height: anchoPantalla < 400 ? 25 : 30,
                      ),

                      // BOTÓN
                      SizedBox(
                        height: 42,
                        width: anchoPantalla < 400 ? 135 : 150,
                        child: ElevatedButton(
                          onPressed: iniciarSesion,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: azul,
                            foregroundColor: Colors.white,
                            elevation: 2,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(22),
                            ),
                          ),
                          child: Text(
                            'Iniciar Sesion',
                            style: TextStyle(
                              fontSize:
                                  anchoPantalla < 400 ? 12 : 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget circulo(double tamanio, Color color) {
    return Container(
      width: tamanio,
      height: tamanio,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
      ),
    );
  }

  Widget campo({
    required TextEditingController controller,
    required String hint,
    required bool ocultar,
    Widget? sufijo,
  }) {
    return SizedBox(
      height: 46,
      child: TextField(
        controller: controller,
        obscureText: ocultar,
        style: const TextStyle(
          fontSize: 14,
          color: Colors.black87,
        ),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(
            fontSize: 13,
            color: Colors.black54,
          ),
          suffixIcon: sufijo,
          filled: true,
          fillColor: const Color(0xFFF9F9F9),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 17,
            vertical: 12,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(24),
            borderSide: const BorderSide(
              color: Colors.black54,
              width: 1,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(24),
            borderSide: const BorderSide(
              color: Colors.black54,
              width: 1,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(24),
            borderSide: const BorderSide(
              color: azulOscuro,
              width: 1.5,
            ),
          ),
        ),
      ),
    );
  }
}